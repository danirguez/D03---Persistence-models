package domain;

public class Administrator extends Actor {
	
	public Administrator() {
		super();
	}

}
